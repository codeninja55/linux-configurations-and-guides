#if ((${PACKAGE_NAME} && ${PACKAGE_NAME} != ""))package ${PACKAGE_NAME} #end
#parse("File Header.java")

/** {description}
  *
  * \@version {major}.{minor}.{rel}
  * \@author Andrew Che <@codeninja55> 
  * 
  * Credits: []
  * License: {license}
  * Maintainer: Andrew Che
  * Email: andrew@codeninja55.me
  * Status: {status}
  * Attribution:
  * [1] 
  * ***********************************************************************************/
  

class ${NAME} {

}
